
var date = new Date(); 
var month = date.getMonth() + 1; 
var weekday = date.getDay(); 
var day = date.getDate(); 
/* cambio de imagen por fecha */
function a(img){
var img = document.getElementById("logo");
 
if (img.src.indexOf('NG1')==-1) return; 
var src;
 
if(month == 7 && day == 5){ 
  src = "img/icon/NGn.png";
 }
 else if(month == 4 && day == 1)
 {
 				src = "img/icon/ngaf.gif";
 }
 	else if(month == 6 && day == 28){ 
  src = "img/icon/NGrainbow.png";
 }
 else if(month == 12 && day == 25){ 
  src = "img/icon/NGxmas.png";
 }
 else if(month == 11 && day == 1){ 
  src = "img/icon/NG1nov.png";
 }else{
 				src = "img/icon/NG1.png";
 }
  
 img.src = src;
}
/* imagen change date */
